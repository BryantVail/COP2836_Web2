"use strict";

var continents = ["africa", "america", "australia", "europe"];
var helloContinents = Array.from(continents, function (conts) {
  return "Hello ".concat(conts, "!");
});
var message = helloContinents.join(" ");
var element = /*#__PURE__*/React.createElement("div", {
  title: "Outer div"
}, /*#__PURE__*/React.createElement("h1", null, "Hello World"));
ReactDOM.render(message, document.querySelector("#contents"));